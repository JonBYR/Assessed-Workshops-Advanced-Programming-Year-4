#include <iostream>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib") // Link the Winsock library
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#define SOCKET int
#define INVALID_SOCKET -1
#endif
#include <cstring>
#include <vector>
#include <thread>
#include <string>
#include <sstream>
#include <algorithm>
#define BUFFER_SIZE 1024
using namespace std;
void dataProcess(vector<int> data, int& ma, int& mi, float& a, float& med) 
{
    float total = 0;
    sort(data.begin(), data.end());
    ma = data[data.size() - 1];
    mi = data[0];
    int oddMidpoint;
    int evenMidpoint1;
    int evenMidpoint2;
    int evenSum;
    if (data.size() % 2 == 1) oddMidpoint = ceil(data.size() / 2);
    else if (data.size() % 2 == 0) 
    {
        evenMidpoint1 = data.size() / 2;
        evenMidpoint2 = evenMidpoint1 + 1;
    }
    for (int i = 0; i < data.size(); i++) 
    {
        total += data[i];
        if (i == oddMidpoint) med = data[oddMidpoint];
        if (i == evenMidpoint1) med = (data[evenMidpoint1] + data[evenMidpoint2]) / 2;
    }
    a = total / data.size();
    cout << a;
}
int main() {
    // Create a TCP socket
    #ifdef _WIN32
    // Initialize Winsock on Windows
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Winsock initialization failed" << std::endl;
        return 1;
    }
    #endif
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    int max;
    int min;
    float average;
    float median;
    vector<int> numbersList;
    if (serverSocket == -1) {
        std::cerr << "Error creating socket." << std::endl;
        return 1;
    }

    // Prepare the server address structure
    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(12345);
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the server address
    if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) 
    {
        #ifdef _WIN32
        std::cerr << "Error binding socket." << WSAGetLastError() << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        #endif
        return 1;
    }

    // Listen for incoming connections
    if (listen(serverSocket, SOMAXCONN) == -1) {
        std::cerr << "Error listening for connections." << std::endl;
        closesocket(serverSocket);
        return 1;
    }

    while (true) {
        // Accept incoming connection
        struct sockaddr_in clientAddress;
        socklen_t clientAddressSize = sizeof(clientAddress);
        int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddress, &clientAddressSize);
        if (clientSocket == -1) {
            std::cerr << "Error accepting connection." << std::endl;
            closesocket(serverSocket);
            return 1;
        }

        // Receive data from the client
        char buffer[BUFFER_SIZE];
        memset(buffer, 0, sizeof(buffer));
        size_t bytesRead = recv(clientSocket, buffer, BUFFER_SIZE, 0);
        if (bytesRead == 0) {
            std::cerr << "Message was not recieved" << std::endl;
            closesocket(clientSocket);
        }
        // Process the received data
        string s(buffer);
        stringstream ss(s);
        string number;
        while (getline(ss, number, ' ')) 
        {
            for(int i = 0; i < number.length(); i++) 
            {
                if (isdigit(number[i]) == false) 
                {
                    std::cout << "Cannot accept client containing anything other than numbers" << std::endl;
                    closesocket(clientSocket);
                    break;
                }
            }
            numbersList.push_back(stoi(number));
        }
        cout << average;
        dataProcess(numbersList, max, min, average, median);
        // Send response to the client
        ostringstream endstring;
        endstring << "Maximum value: " << max << "\nMinimum value: " << min <<  "\nAverage: " << (float)average << "\nMedian: " << (float)median << endl;
        string processString = endstring.str();
        const char* process = processString.c_str();
        size_t bytesSent = send(clientSocket, process, strlen(process), 0);
        if(bytesSent == SOCKET_ERROR) {
            cout << "Failure " << WSAGetLastError(); 
        }
        // Close the client socket
        closesocket(clientSocket);
    }

    // Close the server socket
    closesocket(serverSocket);

    return 0;
}

