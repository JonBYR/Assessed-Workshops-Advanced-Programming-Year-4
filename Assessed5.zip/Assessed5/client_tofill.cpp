#include <iostream>
#include <cstring>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib") // Link the Winsock library
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#define SOCKET int
#define INVALID_SOCKET -1
#endif
#define BUFFER_SIZE 1024
using namespace std;
int main() {
#ifdef _WIN32
    // Initialize Winsock on Windows
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Winsock initialization failed" << std::endl;
        return 1;
    }
#endif
    // Create a TCP socket
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    char buffer[BUFFER_SIZE];
    if (clientSocket == -1) {
        std::cerr << "Error creating socket." << std::endl;
        return 1;
    }

    // Prepare the server address structure
    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(12345);
    serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to the server
    if (connect(clientSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) == -1) {
        std::cerr << "Error connecting to server." << std::endl;
        closesocket(clientSocket);
        return 1;
    }

    // Prompt the user to enter a list of numbers
    std::cout << "Please enter a list of numbers for the server" << std::endl;
    
    // Prepare the list of numbers
    std::cin.getline(buffer, BUFFER_SIZE);
    if (buffer == NULL) {
        std::cout << "Nothing has been entered" << std::endl;
        closesocket(clientSocket);
    }
    // Send data to the server
    int bytesSent = send(clientSocket, buffer, strlen(buffer), 0);
    // Receive data from the server
    char bufferRead[BUFFER_SIZE];
    //memset(bufferRead, 0, sizeof(bufferRead));
    size_t reading = recv(clientSocket, bufferRead, BUFFER_SIZE, 0);
    // Process the received data
    cout << bufferRead;
    // Close the socket
    closesocket(clientSocket);

    return 0;
}

